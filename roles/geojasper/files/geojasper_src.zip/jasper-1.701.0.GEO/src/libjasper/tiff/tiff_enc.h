/*
 * Copyright (c) 2003 Dmitry V. Fedorov <www.dimin.net>
 * DPI, INPE <www.dpi.inpe.br>
 * All rights reserved.
 */


#ifndef TIFF_ENC_H
#define TIFF_ENC_H

#endif
